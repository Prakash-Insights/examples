const style = {
	fontSize: '30px',
}
export default style;
