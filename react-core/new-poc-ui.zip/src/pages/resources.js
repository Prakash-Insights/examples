import React from 'react'
import { Input } from 'antd';

const Resources = () => {
    return (
        <Input placeholder="Basic resources" />
    )
}

export default Resources